package googlehashcode;

public class Veicolo {
	int actualRow;
	int actualColumn;
	boolean occupato;
	
	Veicolo(){
		actualRow=0;
		actualColumn=0;
		occupato=false;
	}
	
	
}
